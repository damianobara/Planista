import java.util.LinkedList;

public class InputList {
    LinkedList<Proces> lp;
    LinkedList<Integer> li;

    public InputList(LinkedList<Proces> lp, LinkedList<Integer> li) {
        this.lp = lp;
        this.li = li;
    }
}
